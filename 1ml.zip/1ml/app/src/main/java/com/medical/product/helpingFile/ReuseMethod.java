package com.medical.product.helpingFile;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import com.medical.product.Ui.CartActivity;
import com.medical.product.Ui.SearchProductActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;


public class ReuseMethod {
    public static Ringtone ringtoneAlarm;
    static SharedPreferences sharedPreferences;
    static SharedPreferences sharedPrfCartArray;
    public static Keystore store;
    public static String retstring = "";
    static SharedPreferences sharedPrfTotalCartItem;

    public static void hideStatusbar(Activity activity) {
      //  activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

    }

    public static void makeTextViewResizable(final TextView tv, final int maxLine, final String expandText, final boolean viewMore) {

        if (tv.getTag() == null) {
            tv.setTag(tv.getText());
        }
        ViewTreeObserver vto = tv.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @SuppressWarnings("deprecation")
            @Override
            public void onGlobalLayout() {

                ViewTreeObserver obs = tv.getViewTreeObserver();
                obs.removeGlobalOnLayoutListener(this);
                if (maxLine == 0) {
                    int lineEndIndex = tv.getLayout().getLineEnd(0);
                    String text = tv.getText().subSequence(0, lineEndIndex - expandText.length() + 1) + " " + expandText;
                    tv.setText(text);
                    tv.setMovementMethod(LinkMovementMethod.getInstance());
                    tv.setText(
                            addClickablePartTextViewResizable(Html.fromHtml(tv.getText().toString()), tv, maxLine, expandText,
                                    viewMore), TextView.BufferType.SPANNABLE);
                } else if (maxLine > 0 && tv.getLineCount() >= maxLine) {
                    int lineEndIndex = tv.getLayout().getLineEnd(maxLine - 1);
                    String text = tv.getText().subSequence(0, lineEndIndex - expandText.length() + 1) + " " + expandText;
                    tv.setText(text);
                    tv.setMovementMethod(LinkMovementMethod.getInstance());
                    tv.setText(
                            addClickablePartTextViewResizable(Html.fromHtml(tv.getText().toString()), tv, maxLine, expandText,
                                    viewMore), TextView.BufferType.SPANNABLE);
                } else {
                    int lineEndIndex = tv.getLayout().getLineEnd(tv.getLayout().getLineCount() - 1);
                    String text = tv.getText().subSequence(0, lineEndIndex) + " " + expandText;
                    tv.setText(text);
                    tv.setMovementMethod(LinkMovementMethod.getInstance());
                    tv.setText(
                            addClickablePartTextViewResizable(Html.fromHtml(tv.getText().toString()), tv, lineEndIndex, expandText,
                                    viewMore), TextView.BufferType.SPANNABLE);
                }
            }
        });

    }

    private static SpannableStringBuilder addClickablePartTextViewResizable(final Spanned strSpanned, final TextView tv,
                                                                            final int maxLine, final String spanableText, final boolean viewMore) {
        String str = strSpanned.toString();
        SpannableStringBuilder ssb = new SpannableStringBuilder(strSpanned);

        if (str.contains(spanableText)) {


            ssb.setSpan(new MySpannable(false) {
                @Override
                public void onClick(View widget) {
                    if (viewMore && tv.getText().length() > 300) {
                        tv.setLayoutParams(tv.getLayoutParams());
                        tv.setText(tv.getTag().toString(), TextView.BufferType.SPANNABLE);
                        tv.invalidate();
                        makeTextViewResizable(tv, -1, "See Less", false);
                    } else {
                        tv.setLayoutParams(tv.getLayoutParams());
                        tv.setText(tv.getTag().toString(), TextView.BufferType.SPANNABLE);
                        tv.invalidate();
                        makeTextViewResizable(tv, 3, ".. See More", true);
                    }
                }
            }, str.indexOf(spanableText), str.indexOf(spanableText) + spanableText.length(), 0);

        }
        return ssb;

    }

    public static void SharedPrefranceCart(Context context, String valuecount) {
        sharedPreferences = context.getSharedPreferences("AddToCart", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("numofvalue", valuecount);
        editor.commit();

    }

    public static String SharedPrefranceCartArray(Context context, String valuecount) {
        sharedPrfCartArray = context.getSharedPreferences("AddToCartArray", MODE_PRIVATE);

        String CartArray = sharedPrfCartArray.getString("CartArray", "");

        String[] temp = CartArray.split("#");

        String addornot = "";
        for (int i = 0; i < temp.length; i++) {
            if (temp[i].equals(valuecount)) {
                addornot = "yes";
            }
        }


        return addornot;


    }


    public static void SetTotalCartItem(Context context, String value) {

        sharedPrfTotalCartItem = context.getSharedPreferences("TotalItemInCart", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrfTotalCartItem.edit();
        editor.putString("totalcartvalue", value);
        editor.commit();
    }

    public static String GetTotalCartItem(Context context) {
        sharedPrfTotalCartItem = context.getSharedPreferences("TotalItemInCart", MODE_PRIVATE);

        String CartTotal = sharedPrfTotalCartItem.getString("totalcartvalue", "");

        return CartTotal;
    }

    public static String SharedPrefranceGetCartValue(Context context) {
        sharedPreferences = context.getSharedPreferences("AddToCart", MODE_PRIVATE);

        String value = sharedPreferences.getString("numofvalue", "");

        if (value.equals("") || value.equals(null)) {
            ReuseMethod.SharedPrefranceCart(context, "0");
            value = sharedPreferences.getString("numofvalue", "");
        }
        return value;
    }


    public static void SharedPrefranceGetCartValueClear(Context context) {
        sharedPreferences = context.getSharedPreferences("AddToCart", MODE_PRIVATE);

        sharedPreferences.edit().clear().commit();

        sharedPrfCartArray = context.getSharedPreferences("AddToCartArray", MODE_PRIVATE);

        sharedPrfCartArray.edit().clear().commit();

    }

    public static void OpenCartActivity(Activity context) {
        context.startActivity(new Intent(context, CartActivity.class));
    }

    public static void OpenSearchActivity(Activity context) {
        context.startActivity(new Intent(context, SearchProductActivity.class));
    }

    public static void setRoundedDrawable(Context context, View view, int backgroundColor, int borderColor) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(0);
        shape.setColor(backgroundColor);
        shape.setStroke((int) 2, borderColor);
        view.setBackgroundDrawable(shape);
    }

    public static void AlarmRingtoon(Context context) {
        Uri alarmTone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        ringtoneAlarm = RingtoneManager.getRingtone(context, alarmTone);
        ringtoneAlarm.play();
    }


    public static String addToCardDatabase(final Context context, final String pid, final String quentity) {
        //if everything is fine
        StringRequest stringRequest = new StringRequest(Request.Method.POST, ApiFileuri.ROOT_HTTP_URL + "product/addcart",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        retstring = response;
                        JSONObject obj = null;
                        try {
                            obj = new JSONObject(retstring);
                            String strstatus = obj.getString("status");

                            if (strstatus.equals("false")) {
                                Toast.makeText(context, obj.getString("product"), Toast.LENGTH_SHORT).show();
                            } else {
                                ReuseMethod.SetTotalCartItem(context, obj.getString("cart-total"));

                                Toast.makeText(context, obj.getString("product").toString(), Toast.LENGTH_SHORT).show();
                                String carttotal = obj.getString("cart-total");
                                SetTotalCartItem(context,carttotal);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error instanceof NoConnectionError)
                            Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                store = Keystore.getInstance(context);
                    params.put("user_id", store.get("id"));
                    params.put("productid", pid);
                    params.put("quentity", quentity);
           /* params.put("email", stremail);
            params.put("phone", strphone);*/
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(500000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);

        return retstring;
    }


    public static String addToCardDatabaseProductDetails(final Context context, final String pid, String quentity, final String addoffer) {
        //if everything is fine
        StringRequest stringRequest = new StringRequest(Request.Method.POST, ApiFileuri.ROOT_HTTP_URL + "product/addcart",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        retstring = response;
                        JSONObject obj = null;
                        try {
                            obj = new JSONObject(retstring);
                            String strstatus = obj.getString("status");

                            if (strstatus.equals("false")) {
                                Toast.makeText(context, obj.getString("product"), Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(context, obj.getString("product"), Toast.LENGTH_SHORT).show();
                                String carttotal = obj.getString("cart-total");
                                SetTotalCartItem(context,carttotal);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error instanceof NoConnectionError)

                            Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                store = Keystore.getInstance(context);
                params.put("user_id", store.get("id"));
                params.put("productid", pid);
                params.put("quentity", "1");
                params.put("additional_offer_id", addoffer);
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(500000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);

        return retstring;
    }


    @SuppressLint("HardwareIds")
    public static String MacAddress(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo wInfo = wifiManager.getConnectionInfo();
        return wInfo.getMacAddress();
    }


}
























