package com.medical.product.Ui;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.medical.product.R;
import com.medical.product.adapter.AdapterFeedbacklist;
import com.medical.product.adapter.Blog_adpater;
import com.medical.product.models.Artical_model;

import java.util.ArrayList;

public class Artical extends AppCompatActivity {

    RecyclerView blog_list;
    ArrayList<Artical_model> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artical);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_keyboard_backspace_black_24dp);
        getSupportActionBar().setTitle("Articles");

        blog_list = (RecyclerView) findViewById(R.id.blog_list);
        list = new ArrayList<>();
        for (int j = 0; j < 10; j++) {
            list.add(new Artical_model());
        }
        Blog_adpater adpater = new Blog_adpater(list, this);
        LinearLayoutManager recyclerlayoutManager = new LinearLayoutManager(getApplicationContext());
        blog_list.setLayoutManager(recyclerlayoutManager);
        blog_list.setHasFixedSize(true);
        blog_list.setAdapter(adpater);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case android.R.id.home:
                finish();
        }
        return (super.onOptionsItemSelected(menuItem));
    }

}
