package com.medical.product.Ui;

public  class Request_order {
    String id,order_id,add_date,user_approved;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getAdd_date() {
        return add_date;
    }

    public void setAdd_date(String add_date) {
        this.add_date = add_date;
    }

    public String getUser_approved() {
        return user_approved;
    }

    public void setUser_approved(String user_approved) {
        this.user_approved = user_approved;
    }
}
