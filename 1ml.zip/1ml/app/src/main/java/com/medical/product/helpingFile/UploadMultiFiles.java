package com.medical.product.helpingFile;

/**
 * Created by Sachin on 1/13/2016.
 */
public class UploadMultiFiles {
    public static final String Rooturl="http://demo.ybisoftech.com/find1click/";
    public static final String urlUpload = Rooturl+"Api/UploadImages";
    public static final String urlUploadProfileImage = Rooturl+"Api/UploadProfileImage";

    public static final String urlUploadUploadProfileDetails = Rooturl+"Api/UploadProfileDetails";



    public static final int REQCODE = 100;
    public static final String imageList = "imageList";
    public static final String imageName = "name";
}
