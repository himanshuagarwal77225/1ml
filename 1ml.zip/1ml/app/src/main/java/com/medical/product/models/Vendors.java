package com.medical.product.models;

public class Vendors {
    String vendor_id,vendor_name,vendor_name_main,vendor_profile,pharmacist_store_name,store_address,dl_number,area_km,average_rating;

    public String getVendor_id() {
        return vendor_id;
    }

    public void setVendor_id(String vendor_id) {
        this.vendor_id = vendor_id;
    }

    public String getVendor_name() {
        return vendor_name;
    }

    public void setVendor_name(String vendor_name) {
        this.vendor_name = vendor_name;
    }

    public String getVendor_name_main() {
        return vendor_name_main;
    }

    public void setVendor_name_main(String vendor_name_main) {
        this.vendor_name_main = vendor_name_main;
    }

    public String getVendor_profile() {
        return vendor_profile;
    }

    public void setVendor_profile(String vendor_profile) {
        this.vendor_profile = vendor_profile;
    }

    public String getPharmacist_store_name() {
        return pharmacist_store_name;
    }

    public void setPharmacist_store_name(String pharmacist_store_name) {
        this.pharmacist_store_name = pharmacist_store_name;
    }

    public String getStore_address() {
        return store_address;
    }

    public void setStore_address(String store_address) {
        this.store_address = store_address;
    }

    public String getDl_number() {
        return dl_number;
    }

    public void setDl_number(String dl_number) {
        this.dl_number = dl_number;
    }

    public String getArea_km() {
        return area_km;
    }

    public void setArea_km(String area_km) {
        this.area_km = area_km;
    }

    public String getAverage_rating() {
        return average_rating;
    }

    public void setAverage_rating(String average_rating) {
        this.average_rating = average_rating;
    }
}
