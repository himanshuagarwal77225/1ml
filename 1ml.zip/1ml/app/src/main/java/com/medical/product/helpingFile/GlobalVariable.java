package com.medical.product.helpingFile;

import com.medical.product.models.HorizontalModelBrands;
import com.medical.product.models.HorizontalModelSaveCategory;

import java.util.ArrayList;

public class GlobalVariable {
    public static ArrayList<HorizontalModelSaveCategory> arraycategory;

    public static ArrayList<HorizontalModelBrands> brandarray;
}
