package com.medical.product.Ui;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseException;
import com.medical.product.R;
import com.medical.product.Utils.Utlity;
import com.medical.product.helpingFile.ApiFileuri;
import com.medical.product.helpingFile.ConnectDetector;
import com.medical.product.helpingFile.DrawableGradient;
import com.medical.product.helpingFile.Keystore;
import com.medical.product.helpingFile.ReuseMethod;
import com.medical.product.helpingFile.SharedPrefManager;
import com.medical.product.helpingFile.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import static com.medical.product.helpingFile.ReuseMethod.hideStatusbar;
import static com.medical.product.helpingFile.ReuseMethod.setRoundedDrawable;

public class SignupPanelActivity extends AppCompatActivity {
    EditText edtPhoneNumber, edtReferralcode, edtEmail,edtname, edtphoneotp;
    TextView txtDateofbirth;
    CheckedTextView chkTxtRefralcode;
    String[] gendername = {"Gender", "Male", "Female", "Other"};
    int genderimage[] = {1, R.drawable.maleicon, R.drawable.femaleicon, R.drawable.othergender};
    //Spinner spinnergender;
    Button btnRegister;
    Boolean isinternetpresent;
    ConnectDetector cd;
    // final Calendar myCalendar = Calendar.getInstance();

    TextView txtresendCounter, txtresend, txtCreateAccount, txtGoToSignup, txtLogin;
    String mobno;

    private String mVerificationId;

    LinearLayout laySignup, layOtp;
    Button btnProceed;

    private Keystore store;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_panel);
        hideStatusbar(this);
        ComponentInitialization();
        ReuseMethod.SharedPrefranceGetCartValueClear(getApplicationContext());
    }

    private void ComponentInitialization() {
        //  txtDateofbirth=(TextView) findViewById(R.id.txtDateofbirth);
        txtresend = (TextView) findViewById(R.id.txtresend);
        txtGoToSignup = (TextView) findViewById(R.id.txtGoToSignup);
        txtresendCounter = (TextView) findViewById(R.id.txtresendCounter);
        edtEmail = (EditText) findViewById(R.id.edtemail);
        edtname = (EditText) findViewById(R.id.edtname);
        layOtp = (LinearLayout) findViewById(R.id.layOtp);
        txtLogin = (TextView) findViewById(R.id.txtLogin);
        laySignup = (LinearLayout) findViewById(R.id.laySignup);
        setRoundedDrawable(this, edtEmail, 0xffffffff, 0xffa3a2a2);
        btnProceed = (Button) findViewById(R.id.btnProceed);
        btnProceed.setBackgroundDrawable(new DrawableGradient(new int[]{0xffffffff, 0xffffffff, 0xffffffff}, 0).SetTransparency(20));
        // spinnergender=(Spinner)findViewById(R.id.spinnergender);
        //   spinnergender.setPopupBackgroundResource(R.drawable.spinner_popup_background);
        edtPhoneNumber = (EditText) findViewById(R.id.edtPhoneNumber);
        setRoundedDrawable(this, edtPhoneNumber, 0xffffffff, 0xffa3a2a2);
        setRoundedDrawable(this, edtname, 0xffffffff, 0xffa3a2a2);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        chkTxtRefralcode = (CheckedTextView) findViewById(R.id.chkTxtRefralcode);
        edtReferralcode = (EditText) findViewById(R.id.edtReferralcode);
        setRoundedDrawable(this, edtReferralcode, 0xffffffff, 0xffa3a2a2);
        edtphoneotp = (EditText) findViewById(R.id.edtphoneotp);
        edtphoneotp.setBackgroundDrawable(new DrawableGradient(new int[]{0xffffffff, 0xffffffff, 0xffffffff}, 0).SetTransparency(20));
        //   spinnergender.setPrompt("Select gender...");
     /*   SpinnerCustomAdapter customAdapter=new SpinnerCustomAdapter(getApplicationContext(),genderimage,gendername);
        spinnergender.setAdapter(customAdapter);*/
//        btnRegister.setBackgroundDrawable( new DrawableGradient(new int[] { 0xffffffff, 0xffffffff, 0xffffffff }, 0).SetTransparency(20));
    }

    public void clickFunction(View view) {
        switch (view.getId()) {
           /* case R.id.txtDateofbirth:
                new DatePickerDialog(SignupPanelActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                break;*/
            case R.id.btnRegister:
                String strphone = edtPhoneNumber.getText().toString();
                String stremail = edtEmail.getText().toString();
                String strname = edtname.getText().toString();
                Boolean mail = isValidMail(stremail);
                if (strphone.equals("") || strphone.length() != 10) {
                    Toast.makeText(getApplicationContext(), "Incorrect Phone Number", Toast.LENGTH_SHORT).show();
                } else if (stremail.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please Enter Email Id", Toast.LENGTH_SHORT).show();
                }  else if (strname.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please Enter name", Toast.LENGTH_SHORT).show();
                }
                else if (!mail.equals(true)) {
                    Toast.makeText(getApplicationContext(), "InValid Email", Toast.LENGTH_SHORT).show();
                } else {

                    CreateAccountMethod(edtEmail.getText().toString(), edtPhoneNumber.getText().toString(),edtname.getText().toString());

                }
                break;
            case R.id.chkTxtRefralcode:
                if (chkTxtRefralcode.isChecked()) {
                    chkTxtRefralcode.setChecked(false);
                    edtReferralcode.setVisibility(View.VISIBLE);
                } else {
                    chkTxtRefralcode.setChecked(true);
                    edtReferralcode.setVisibility(View.GONE);
                }
                break;
            case R.id.btnProceed:
                String strotp = edtphoneotp.getText().toString();

                if (strotp.equals("") || strotp.length() != 6) {
                    Toast.makeText(getApplicationContext(), "Incorrect Phone Number", Toast.LENGTH_SHORT).show();
                } else {
                    //verifyVerificationCode(strotp);
                }
                break;
            case R.id.txtresend:
                //resendVerificationCode(edtphoneotp.getText().toString(),mResendToken);
                break;
            case R.id.txtGoToSignup:
                laySignup.setVisibility(View.VISIBLE);
                layOtp.setVisibility(View.GONE);
                break;

            case R.id.txtLogin:
                finish();
                break;


        }
    }


    private void CountDownResendOtp() {
        txtresendCounter.setVisibility(View.VISIBLE);
        CountDownTimer countDownTimer = new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
                txtresendCounter.setText("Resend in " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                txtresendCounter.setVisibility(View.GONE);
                txtresend.setVisibility(View.VISIBLE);
                // txtresendCounter.setText("done!");
            }
        }.start();
    }


    private void CreateAccountMethod(final String stremail, final String strphone, final String name) {
        //if everything is fine
        final Dialog dialog = Utlity.show_progress(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, ApiFileuri.ROOT_HTTP_URL + "user/set",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        JSONObject obj = null;
                        try {
                            Utlity.dismiss_dilog(SignupPanelActivity.this, dialog);
                            obj = new JSONObject(response);
                            String strstatus = obj.getString("status");
                            if (strstatus.equals("false")) {
                                Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                            } else {
                                JSONArray jsonArray = new JSONArray(obj.getJSONArray("user_data").toString());
                                for (int j = 0; j < jsonArray.length(); j++) {
                                    JSONObject objnew = new JSONObject();
                                    objnew = jsonArray.getJSONObject(0);

                                    Iterator<String> iter = objnew.keys();
                                    while (iter.hasNext()) {
                                        String key = iter.next();
                                        store = Keystore.getInstance(getApplicationContext());//Creates or Gets our key pairs.  You MUST have access to current context!
                                        store.put(key, (String) objnew.get(key));
                                    }
                                }

                                startActivity(new Intent(getApplicationContext(), Dashbord.class));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Utlity.dismiss_dilog(SignupPanelActivity.this, dialog);
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", stremail);
                params.put("phone", strphone);
                params.put("name", name);
                params.put("token", SharedPrefManager.getInstance(getApplicationContext()).getDeviceToken());
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(500000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private boolean isValidMail(String email) {
        boolean check;
        Pattern p;
        Matcher m;
        String EMAIL_STRING = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        p = Pattern.compile(EMAIL_STRING);
        m = p.matcher(email);
        check = m.matches();
        return check;
    }


}
