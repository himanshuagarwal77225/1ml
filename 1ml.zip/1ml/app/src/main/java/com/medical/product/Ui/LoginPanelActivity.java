package com.medical.product.Ui;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.medical.product.R;
import com.medical.product.Utils.Utlity;
import com.medical.product.helpingFile.ApiFileuri;
import com.medical.product.helpingFile.ConnectDetector;
import com.medical.product.helpingFile.DrawableGradient;
import com.medical.product.helpingFile.Keystore;
import com.medical.product.helpingFile.ReuseMethod;
import com.medical.product.helpingFile.SharedPrefManager;
import com.medical.product.helpingFile.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class LoginPanelActivity extends AppCompatActivity {
    Button btnLogin;
    LinearLayout layOtp, layLogin;
    String strphone;
    //   FirebaseAuth mAuth;
    TextView txtCreateAccount, txtGoToLogin;
    EditText edtphoneemail;
    DocumentReference documentReference;
    private String mVerificationId;
    Context context = LoginPanelActivity.this;
    EditText edtphoneotp;
    Button btnProceed;
    FirebaseFirestore db;
    PhoneAuthCredential credential;
    FirebaseAuth firebaseAuth;
    TextInputLayout layoutTextInput;
    boolean valtype;
    /*  private String mVerificationId;
      private PhoneAuthProvider.ForceResendingToken mResendToken;*/
    TextView txtresendCounter, txtresend;
    Keystore store;
    Boolean isinternetpresent;
    ConnectDetector cd;
    // sms permission
    Dialog nesteddialog;
    String verifyCode;
    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
    };
    ProgressDialog dialog;
    Dialog dialog1;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    Handler handler;
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_panel);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        handler=new Handler(getApplicationContext().getMainLooper());
        componentInitialization();

        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }
        firebaseAuth = FirebaseAuth.getInstance();
       mCallbacks= new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
           @Override
           public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
               }

           @Override
           public void onVerificationFailed(FirebaseException e) {
               Toast.makeText(LoginPanelActivity.this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
           }
           @Override
           public void onCodeSent(String verificationId,PhoneAuthProvider.ForceResendingToken token){
               mVerificationId = verificationId;
               handler.post(new Runnable() {
                   @Override
                   public void run() {
                       Utlity.dismiss_dilog(LoginPanelActivity.this, nesteddialog);
                       Toast.makeText(getApplicationContext(), "Verification code has been sent", Toast.LENGTH_SHORT).show();
                       dialog1 = new Dialog(LoginPanelActivity.this);
                       dialog1.setContentView(R.layout.verification_dialog);
                       dialog1.setCancelable(false);
                       final TextView textView = dialog1.findViewById(R.id.dialog_text);
                       textView.setText("We sent a 6 digit verification code to "+ strphone +". Enter it below.");
                       final TextView verifyButton = dialog1.findViewById(R.id.btn_verify);
                       TextView resendButton = dialog1.findViewById(R.id.btn_resend);
                       verifyButton.setOnClickListener(new View.OnClickListener() {
                           @Override
                           public void onClick(View v) {

                               EditText verificationCode  = dialog1.findViewById(R.id.code);
                               verifyCode = verificationCode.getText().toString();
                               verifyButton.setClickable(false);
                               verifyButton.setEnabled(false);
                               if(!verifyCode.trim().isEmpty()) {

                                   credential = PhoneAuthProvider.getCredential(mVerificationId, verifyCode);
                                   signInWithPhoneAuthCredential(credential);
                               }else{
                                   Toast.makeText(getApplicationContext(), "Invalid Input", Toast.LENGTH_SHORT).show();
                               }

                           }

                       });
                       resendButton.setOnClickListener(new View.OnClickListener() {
                           @Override
                           public void onClick(View v) {
                               dialog1.dismiss();
                           }
                       });
                       dialog1.show();
                   }
               });
           }
       };

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Check if the intent contains an AppInvite and then process the referral information.
        Intent intent = getIntent();

    }


    private void componentInitialization() {
        edtphoneemail = (EditText) findViewById(R.id.edtphoneemail);

        txtCreateAccount = (TextView) findViewById(R.id.txtCreateAccount);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        layOtp = (LinearLayout) findViewById(R.id.layOtp);
        layLogin = (LinearLayout) findViewById(R.id.layLogin);
        txtGoToLogin = (TextView) findViewById(R.id.txtGoToLogin);

        edtphoneotp = (EditText) findViewById(R.id.edtphoneotp);
        edtphoneotp.setBackgroundDrawable(new DrawableGradient(new int[]{0xffffffff, 0xffffffff, 0xffffffff}, 0).SetTransparency(20));

        btnProceed = (Button) findViewById(R.id.btnProceed);

        txtresend = (TextView) findViewById(R.id.txtresend);
        txtresendCounter = (TextView) findViewById(R.id.txtresendCounter);

    }


    public boolean isStringInt(String text) {

        if (!text.equals("")) {
            String saf = text.substring(0, 1);
            try {
                int num = Integer.parseInt(saf);
                return true;
            } catch (NumberFormatException e) {
                return false;
            } catch (StringIndexOutOfBoundsException e) {
                return false;
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }


    public void clickFunction(View view) {
        switch (view.getId()) {
            case R.id.txtCreateAccount:
                startActivity(new Intent(getApplicationContext(), SignupPanelActivity.class));
                break;
            case R.id.btnLogin:
                cd = new ConnectDetector(getApplicationContext());
                isinternetpresent = cd.isConnectToInternet();
                if (isinternetpresent) {
                    strphone = "91"+edtphoneemail.getText().toString();
                    if (strphone.equals("") || strphone.length() != 10) {
                        Toast.makeText(getApplicationContext(), "Incorrect Phone Number", Toast.LENGTH_SHORT).show();
                    } else {
                        login(strphone);
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Internet Not Present", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.btnProceed:
                cd = new ConnectDetector(getApplicationContext());
                isinternetpresent = cd.isConnectToInternet();
                if (isinternetpresent) {
                    String strotp = edtphoneotp.getText().toString();
                    if (strotp.equals("") || strotp.length() != 6) {
                        Toast.makeText(getApplicationContext(), "Incorrect Phone Number", Toast.LENGTH_SHORT).show();
                    } else {
                        // verifyVerificationCode(strotp);
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Internet Not Present", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.txtresend:
                cd = new ConnectDetector(getApplicationContext());
                isinternetpresent = cd.isConnectToInternet();
                if (isinternetpresent) {
                    txtresendCounter.setVisibility(View.VISIBLE);
                    txtresend.setVisibility(View.GONE);
                    CountDownResendOtp();
                } else {
                    Toast.makeText(getApplicationContext(), "Internet Not Present", Toast.LENGTH_SHORT).show();

                }
                break;
            case R.id.txtGoToLogin:
                layLogin.setVisibility(View.VISIBLE);
                layOtp.setVisibility(View.GONE);
                break;
        }
    }

    private void verifyVerificationCode(final String strotp) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, ApiFileuri.ROOT_HTTP_URL + "user/loginu",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject obj = null;
                        try {
                            obj = new JSONObject(response);
                            String strstatus = obj.getString("status");
                            if (strstatus.equals("false")) {
                                Toast.makeText(getApplicationContext(), "Your account is suspend !", Toast.LENGTH_SHORT).show();
                            } else {
                                startActivity(new Intent(getApplicationContext(), Dashbord.class));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error instanceof NoConnectionError)
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                String strphone = edtphoneemail.getText().toString();
                params.put("phone", strphone);
                params.put("otp", strotp);
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(500000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    public void addpermission() {
        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }
    }

    private boolean checkWriteExternalPermission(String permission) {
        int res = getApplicationContext().checkCallingOrSelfPermission(permission);
        return (res == PackageManager.PERMISSION_GRANTED);
    }

    private void CountDownResendOtp() {
        txtresendCounter.setVisibility(View.VISIBLE);
        CountDownTimer countDownTimer = new CountDownTimer(30000, 1000) {
            public void onTick(long millisUntilFinished) {
                txtresendCounter.setText("Resend in " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                txtresendCounter.setVisibility(View.GONE);
                txtresend.setVisibility(View.VISIBLE);
                // txtresendCounter.setText("done!");
            }
        }.start();
    }

    public void closeLogin() {
        this.finish();
    }

    private void LoginAccountMethod() {
        //if everything is fine
        final Dialog dialog = Utlity.show_progress(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, ApiFileuri.ROOT_HTTP_URL + "user/loginu",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject obj = null;
                        try {
                            Utlity.dismiss_dilog(LoginPanelActivity.this, dialog);
                            obj = new JSONObject(response);
                            String strstatus = obj.getString("status");
                            if (strstatus.equals("false")) {
                                Toast.makeText(getApplicationContext(), "You have not register & may be your account suspend !", Toast.LENGTH_SHORT).show();
                            } else {
                                JSONArray jsonArray = new JSONArray(obj.getJSONArray("user_data").toString());
                                for (int j = 0; j < jsonArray.length(); j++) {
                                    JSONObject objnew = new JSONObject();
                                    objnew = jsonArray.getJSONObject(0);
                                    Iterator<String> iter = objnew.keys();
                                    while (iter.hasNext()) {
                                        String key = iter.next();
                                        store = Keystore.getInstance(getApplicationContext());
                                        store.put(key, (String) objnew.get(key));
                                    }
                                }
                                startActivity(new Intent(getApplicationContext(), Dashbord.class));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        if (error instanceof NoConnectionError)
                            Utlity.dismiss_dilog(LoginPanelActivity.this, dialog);
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                String strphone = edtphoneemail.getText().toString();
                params.put("login_for", strphone);
                params.put("macid", ReuseMethod.MacAddress(getApplicationContext()));
                params.put("token", SharedPrefManager.getInstance(getApplicationContext()).getDeviceToken());
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(500000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    public boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }

            }
        }
        return true;
    }
    public void login(final String phone){
        nesteddialog = Utlity.show_progress(this);
        new  Thread(new Runnable() {
            @Override
            public void run() {
                sendCode(phone);


            }
        }).start();
    }
    private void sendCode(String  phone) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phone,
                60,
                TimeUnit.SECONDS,
                this,
                mCallbacks

        );

    }
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential){
        dialog.dismiss();
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            database(strphone);

                        }
                        else{
                            if(task.getException()instanceof FirebaseAuthInvalidCredentialsException){
                                Toast.makeText(LoginPanelActivity.this, "Credential error !! ", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
    }
    private  void database(final String phone){
        db = FirebaseFirestore.getInstance();
        documentReference = db.collection(phone).document("ProfileInformation");
        documentReference.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()) {
                    Intent intent = new Intent(LoginPanelActivity.this,Dashbord.class);
                    startActivity(intent);
                    finish();

                }else{
                    checkdata(phone);
                }
            }
        });

    }
    private void checkdata(final String phoneNumber) {

        Intent intent = new Intent(LoginPanelActivity.this,SignupPanelActivity.class);
        intent.putExtra("phoneNumber",phoneNumber);
        intent.putExtra("Main",true);
        startActivity(intent);
        finish();
    }
}
