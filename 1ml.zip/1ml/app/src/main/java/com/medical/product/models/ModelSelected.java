package com.medical.product.models;

public class ModelSelected {
    private String images;



}
